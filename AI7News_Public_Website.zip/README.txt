# AI 7 Generation Tech News - Public Website

This folder is ready to be deployed on:

- GitHub Pages: https://pages.github.com
- Netlify: https://www.netlify.com

## How to Use

1. Upload the `index.html` file to GitHub or Netlify.
2. Replace the AdSense placeholder with your real AdSense code.
3. Done! Your site is now live with ad support.

Developed with ❤️ by ChatGPT
